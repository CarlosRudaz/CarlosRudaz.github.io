from django.apps import AppConfig


class ServiciosappConfig(AppConfig):
    name = 'ServiciosApp'
